# 🇺🇿 UzLang — O‘zbekcha dasturlash tili

**UzLang** — bu yangi boshlovchilar uchun mo‘ljallangan, o‘zbek tilida yoziladigan, Python’ga o‘xshash sintaksisga ega, minimalist dasturlash tili.  
Ustunliklari: oddiy, tushunarli va milliy!

---

## 🎯 Maqsad

- Yangi o‘rganuvchilar uchun tabiiy, ona tilida yoziladigan dasturlash muhiti yaratish.
- Dasturlashni o‘rganishni maksimal darajada osonlashtirish.
- O‘zbek dasturchilariga milliy ifoda imkoniyatini beruvchi til yaratish.

---

## 🔤 Sintaksis namunasi

```uzlang
agar raqam > 3
    yoz "Bu katta son"
